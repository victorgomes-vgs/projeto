# Worklog

---
Task ID: 1
Agent: Z.ai Code (main)
Task: Transformar o game.html (Truth or Dare XXX) na versão ULTIMATE v2.0 — apenas acrescentando conteúdo (proibido mudar/alterar/remover), com: playlist de vídeos de fundo (video1.mp4…video15.mp4) com tom avermelhado, perguntas/desafios picantes novos, exemplos, imagens e painel de prompts prontos para o Wan.

Work Log:
- Lidos e comparados os uploads `upload/game.html` (XXX/Ultimate) e `upload/game-soft.html` (Soft) — 3.734 linhas cada; base escolhida: game.html.
- Mapeada a estrutura: CSS (styles), telas (lang/home/game/admin), STRINGS i18n (pt-BR/en-US), DECKS_BY_LANG (truth 1000s, dareown 2000s, dareint 3000s, ultimate 4000s, intimacy 5000s), mergeDecks (pula as 5 chaves padrão — cartas novas em defaultDecks sempre aparecem), revealCard com suporte a `imageUrl`, boot/init.
- Base copiada para `public/game.html` e TODAS as mudanças são ADITIVAS:
  - CSS novo (bloco "ULTIMATE ADD-ONS v2.0") antes de `</style>`: camada `.bg-video-layer`, tint `.bg-red-tint` (multiply) + `.bg-red-glow`, fallback animado, véu translúcido `body.vbg-on .velvet-bg`, controles flutuantes `.vbg-controls`, modais `.x-modal/.x-box`, galeria, age gate 18+, botões `.btn-hot`.
  - HTML novo após `<body>`: camada de vídeo (2 <video> para crossfade + tint vermelho + glow + fallback) e portão 18+ (sessionStorage `tod3x-age`).
  - Home: linha nova de botões — 🔥 EXEMPLOS · EXAMPLES, 🎥 PROMPTS WAN (IA), 🖼 GALERIA PICANTE.
  - Controles fixos canto inferior direito: 🎬 fundo ON/OFF, 🔊 som, ⏭ próximo vídeo, 🔥 prompts, 💡 exemplos.
  - Modais novos: EXEMPLOS (3 cartas aleatórias ao vivo por baralho), PROMPTS WAN (12 prompts de imagem + 6 de vídeo + prompt negativo + COMO USAR, com botão COPIAR), GALERIA PICANTE (img1.jpg…img12.jpg da mesma pasta).
  - JS novo (IIFE no fim do script): controlador BGVideo — playlist video1→video20 com descoberta sequencial (probe), retry 1x por índice, crossfade entre 2 elementos, ciclo infinito pelos encontrados, fallback animado se nada existir, toggle som (volume 0.55), skip manual; guard de `error` no card-img (esconde imagens ausentes); portão 18+; helpers copy/clipboard com fallback.
  - 70 cartas novas (IDs 9000–9414) nos 5 baralhos, em pt-BR E en-US (truth +16, dareown +12, dareint +15, ultimate/surpresa +12, intimacy/ultimate-XXX +15) — cartas novas referenciam img1..img6.jpg quando relevante.
- Divergências vs. original: 0 linhas removidas; 10 linhas ganharam APENAS vírgula final (últimos itens dos arrays, necessário para anexar); +657 linhas novas.
- Assets gerados: `public/img1..6.jpg` (arte ambiente sensual/cinematográfica via z-ai image CLI; gerador tem filtro — prompts explícitos bloqueados, arte consistente e segura) e `public/video1..4.mp4` (placeholders vermelhos ffmpeg 8s 720p: gradients/hue/geq/gblur; usuário substitui pelos 15 dele com os mesmos nomes).
- Integração Next.js: `src/app/page.tsx` = iframe full-screen de `/game.html` (permite autoplay/clipboard/fullscreen); `src/app/layout.tsx` com metadata "Truth or Dare XXX · Ultimate".
- Bugs encontrados e corrigidos durante verificação com Agent Browser:
  1. `confirmAge` chamava `BG.ensureStart` inexistente → método adicionado.
  2. Playlist não descobria video2+ (só ciclava o 1º encontrado) → lógica de probe sequencial criada.
  3. Swap de referências no 1º `playing` fazia cur==oth e a sondagem matava o vídeo em execução → swap só quando `el !== BG.cur`.
  4. Evento `playing` duplicado re-sondava e pulava o vídeo em pré-carga (video2 sumia) → guard `BG.activeIdx` (idempotente por vídeo).
  5. Falha transitória excluía o vídeo para sempre → retry 1x por índice (probeRetryOrSkip/bgFail).
- Verificação Agent Browser (rota / e /game.html): age gate 18+ ✓, tela de idioma com vídeo vermelho atrás ✓, home com 3 botões novos ✓, EXEMPLOS com cartas ao vivo (incluindo novas) ✓, PROMPTS WAN com COPIAR ✓, GALERIA com 6 imagens ✓, adicionar 2 jogadores ✓, girar roda → mover → resultado VERDADE ✓, carta com imagem (img1.jpg) exibida ✓, validação e próximo jogador ✓, skip de vídeo manual ✓, toggle 🎬 ✓, ciclo da playlist 1→2→3→4 ✓ (found=[1,2,3], oth=4, probe=5), mobile 390x844 ✓, admin com contas novas (57/30/27) ✓, zero erros no dev.log, lint limpo.

Stage Summary:
- Entregável principal: `/home/z/my-project/public/game.html` (servido em /game.html e embutido na rota / via iframe) — versão ULTIMATE v2.0, 100% aditiva sobre o original.
- Para usar localmente: baixar game.html + imgs + vídeos para UMA pasta; colocar video1.mp4…video15.mp4 e img1.jpg…img12.jpg (gerados no Wan com os prompts do botão 🎥 PROMPTS WAN) na mesma pasta e abrir game.html.
- Pasta public agora contém: game.html, img1-6.jpg (base), video1-4.mp4 (placeholders que o usuário substitui).
- Nenhum conteúdo original foi alterado ou removido (verificado por diff: 0 remoções; 10 linhas com vírgula adicional apenas).
