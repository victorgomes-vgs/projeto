import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Truth or Dare XXX · Ultimate",
  description: "Truth or Dare Ultimate 18+ — perguntas picantes, desafios ultimate, fundo em vídeo com tom avermelhado. Adults only.",
  keywords: ["truth or dare", "verdade ou desafio", "adult game", "18+", "party game"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Truth or Dare XXX · Ultimate",
    description: "Adults only 18+ party game",
    siteName: "Truth or Dare XXX",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Truth or Dare XXX · Ultimate",
    description: "Adults only 18+ party game",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
