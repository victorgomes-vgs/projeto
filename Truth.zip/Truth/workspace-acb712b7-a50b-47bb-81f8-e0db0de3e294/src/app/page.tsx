export default function Home() {
  return (
    <main
      style={{
        position: 'fixed',
        inset: 0,
        background: '#0a0a0a',
        overflow: 'hidden',
      }}
    >
      <iframe
        src="/game.html"
        title="Truth or Dare XXX · Ultimate"
        allow="autoplay; fullscreen; clipboard-write"
        style={{
          width: '100%',
          height: '100%',
          border: '0',
          display: 'block',
        }}
      />
    </main>
  )
}
